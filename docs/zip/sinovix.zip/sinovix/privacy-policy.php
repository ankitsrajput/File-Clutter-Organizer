<?php
    include_once('header.php');
?>
<div class="container-xxl bg-gradient-1 page-header">
                <div class="container text-center">
                    <h1 class="text-white animated zoomIn mb-3">Privacy Policy</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                            <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Privacy Policy</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Navbar & Hero End -->
        <!-- Privacy Policy Start -->
<div class="container-xxl py-0">
            <div class="container">
                <div class="mx-auto text-center wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <div class="d-inline-block rounded-pill text-white bg-gradient-1 px-4 mb-3">How we work</div>
                    <!-- <h2 class="mb-5">Your Role and Duties</h2> -->
                </div>
                <div class="row g-5 align-items-center">
                    <div class="col-lg-12 text-center text-lg-start">
                        <p class="pb-3 animated zoomIn">
                            Sinovix ("we," "us," "our") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our services.
                        </p>
                        <h4 class="mb-4 animated zoomIn">Information Collection</h4>
                        <p class="pb-0 animated zoomIn">
                            <strong>Personal Information : </strong>We collect personal information such as your name, email address, phone number, and payment details(with your permission) when you register for our services or contact us. This may also include student or user data collected through our platform, but only as authorized by our clients and in accordance with applicable laws.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Usage Data : </strong>We collect information on how you interact with our website and services, including IP addresses, browser types, and pages visited and device information.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Data Security : </strong>We implement reasonable security measures to protect your information from unauthorized access, use, or disclosure. However, no method of transmission over the internet or electronic storage is completely secure.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Change To This Privacy : </strong>We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new policy on our website. Your continued use of our services after any changes constitutes your acceptance of the new policy.
                        </p>
                        <h4 class="mb-4 animated zoomIn">Your Rights</h4>
                        <p class="pb-0 animated zoomIn">
                            <strong>Access and Update : </strong>You have the right to access and update your personal information at any time.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Deletion : </strong> You may request the deletion of your personal information, subject to certain exceptions required by law.
                        </p>
                        <h4 class="mb-4 animated zoomIn">How we use your information</h4>
                        <ul class="pb-0 animated zoomIn">
                            <li>Create and maintain your account(if applicable)</li>
                            <li>Provide and improve the Platform and Services</li>
                            <li>To notify you about changes to our services.</li>
                            <li>To provide customer support.</li>
                            <li>Comply with legal obligations</li>
                        </ul>
                        <h4 class="mb-4 animated zoomIn">Data Sharing</h4>
                        <p class="pb-0 animated zoomIn">
                        We do not share your personal information with companies, organizations or individuals outside, except <strong>BigRock</strong> in the following cases in which we have used BigRock's hosting service.
                        </p>
                        <h4 class="mb-4 animated zoomIn">Contact Us</h4>
                        <p class="pb-0 animated zoomIn">
                            If you have any questions or concerns about this Privacy Policy, please contact us at:
                        </p>
                        <ul class="pb-0 animated zoomIn">
                            <li>Email: info@sinovix.com</li>
                            <li>Phone: +91-7651849593</li>
                            <li>Address: Ground Floor Ramvilas Guest House Jasmai, Bypass Rd, Farrukhabad, Uttar Pradesh - 209625</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    <!-- Privacy Policy End -->

    <!-- Footer Start -->
    <?php
        include_once('footer.php');
    ?>
    <!-- Footer End -->