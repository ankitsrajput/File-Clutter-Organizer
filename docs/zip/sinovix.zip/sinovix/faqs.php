<?php
    include_once('header.php');
?>
    <!-- Navbar End Here -->
    <div class="container-xxl bg-gradient-1 page-header">
        <div class="container text-center">
            <h1 class="text-white animated zoomIn mb-3">FAQs</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                    <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page">FAQs</li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- Navbar & Hero End -->

    <div class="container-xl py-1 wow fadeInUp pageNotFound" data-wow-delay="0.1s">
        <div class="container text-center">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <!-- <i class="bi bi-exclamation-triangle display-1 text-color-1"></i> -->
                    <!-- <h1 class="display-1">404</h1> -->
                    <!-- <img src="img/404.png" alt="Page Not Found" class="display-1 img-fluid"></img> -->
                    <h1 class="mb-4">FAQs Comming Soon</h1>
                    <p class="mb-4">We’re sorry, the page you have looked for does not exist in our website! Maybe go to our home page or try to use a search?</p>
                    <a class="btn btn-primary btn-border bg-gradient-1 rounded-pill py-3 px-5" href="index.php">Go Back To Home</a>
                </div>
            </div>
        </div>
    </div>
<?php
    include_once('footer.php');
?>