            <!-- Header Start -->
            <?php
                include_once('header.php');
            ?>
            <!-- Header End -->

            <div class="container-xxl bg-gradient-1 page-header">
                <div class="container text-center">
                    <h1 class="text-white  animated zoomIn mb-3">Features</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                            <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Features</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Navbar & Hero End -->


        <!-- Features Start -->
        <div class="container-xxl py-6">
            <div class="container">
                <div class="row g-5">
                    <div class="col-lg-5 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="d-inline-block rounded-pill text-white px-4 mb-3 bg-gradient-1">Features</div>
                        <h2 class="mb-4">Why Mostly Colleges, Schools, & Institutes Choose Sinovix ?</h2>
                        <p class="p-justify">Colleges, schools, and institutes prefer Sinovix for its comprehensive ERP solutions that streamline administrative tasks, enhance communication, and improve resource management.</p>
                        <p>Our user-friendly platform making it the preferred choice for educational institutions.</p>
                        <a class="btn btn-primary btn-border rounded-pill py-3 px-5 mt-2 bg-gradient-1" href="feature.php">Read More</a>
                    </div>
                    <div class="col-lg-7">
                        <div class="row g-5">
                            <div class="col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="flex-shrink-0 btn-square bg-gradient-1 rounded-circle me-3">
                                        <i class="fa fa-cubes text-white"></i>
                                    </div>
                                    <h6 class="mb-0">Best ERP Solution</h6>
                                </div>
                                <span>Sinovix offers the best ERP solution for schools, colleges, and institutes.</span>
                            </div>
                            <div class="col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="flex-shrink-0 btn-square bg-gradient-1 rounded-circle me-3">
                                        <i class="fa fa-percent text-white"></i>
                                    </div>
                                    <h6 class="mb-0">99.9% Satishfied Clients</h6>
                                </div>
                                <span>We are boasts a 99.9% client satisfaction rate.</span>
                            </div>
                            <div class="col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="flex-shrink-0 btn-square bg-gradient-1 rounded-circle me-3">
                                        <i class="fa fa-file-word text-white"></i>
                                    </div>
                                    <h6 class="mb-0">Fully Customized Reporting</h6>
                                </div>
                                <span>Generate fully customized reports tailored to your school's needs.</span>
                            </div>
                            <div class="col-sm-6 wow fadeInUp" data-wow-delay="0.7s">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="flex-shrink-0 btn-square bg-gradient-1 rounded-circle me-3">
                                        <i class="fa fa-smile-beam text-white"></i>
                                    </div>
                                    <h6 class="mb-0">100% Safe & Secure</h6>
                                </div>
                                <span>Ensure your data is 100% safe & secure with Sinovix, offering robust encryption.</span>
                            </div>
                            <div class="col-sm-6 wow fadeInUp" data-wow-delay="0.9s">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="flex-shrink-0 btn-square bg-gradient-1 rounded-circle me-3">
                                        <i class="fa fa-user-tie text-white"></i>
                                    </div>
                                    <h6 class="mb-0">Multi User Login</h6>
                                </div>
                                <span>Facilitate collaboration and efficient management with multiuser login capabilities.</span>
                            </div>
                            <div class="col-sm-6 wow fadeInUp" data-wow-delay="1s">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="flex-shrink-0 btn-square bg-gradient-1 rounded-circle me-3">
                                        <i class="fa fa-headset text-white"></i>
                                    </div>
                                    <h6 class="mb-0">24/7 Customer Support</h6>
                                </div>
                                <span>Receive round-the-clock assistance with our 24x7 customer support.</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Features End -->
        

        <!-- Footer Start -->
        <?php
            include_once('footer.php');
        ?>
        <!-- Footer End -->
