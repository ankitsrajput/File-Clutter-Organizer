    <!-- Header Start -->
        <?php
            include_once('header.php');
        ?>
    <!-- Header End -->


            <div class="container-xxl bg-gradient-1 page-header">
                <div class="container text-center">
                    <h1 class="text-white animated zoomIn mb-3">Terms & Conditions</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                            <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Terms & Conditions</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Navbar & Hero End -->


        <!-- Terms Start -->
        <div class="container-xxl py-0">
            <div class="container">
                <div class="mx-auto text-center wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <div class="d-inline-block rounded-pill text-white bg-gradient-1 px-4 mb-3">Your Role and Duties</div>
                    <!-- <h2 class="mb-5">Your Role and Duties</h2> -->
                </div>
                <div class="row g-5 align-items-center">
                    <div class="col-lg-12 text-center text-lg-start">
                        <p class="pb-3 animated zoomIn">
                            By accessing this website, you are agreeing to be bound by this website’s Terms and Conditions of Use, all applicable laws, and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree to these Terms, please do not use our website or services.
                        </p>
                        <h4 class="mb-4 animated zoomIn">Use Of Service</h4>
                        <p class="pb-0 animated zoomIn">
                            <strong>Eligibility : </strong>You must be at least 18 years old to use our services. By using our services, you represent and warrant that you meet this age requirement. Otherwise we will not be responsible for anything.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Account Registration : </strong>For use of our services you require  to register an account by himself or by us. You agree to provide accurate and complete information and to update it as necessary. You are responsible for maintaining the confidentiality of your account and password and for all activities that occur under your account. In case if you lose your data or any information then you can't take any legal step against on our services or company.
                            <p class="pb-0 animated zoomIn">
                            You must provide your legal full name, a valid email address, and any other information requested in order to complete the signup process.
                            </p>
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>User Conduct : </strong>Users must not misuse the ERP system. Any unauthorized access, sharing, or manipulation of data will result in immediate suspension of services.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Service Availability : </strong>We do not guarantee that our services will always be available or uninterrupted. We may suspend, withdraw, or restrict the availability of all or any part of our services for business and operational reasons.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Maintenance and Updates : </strong>We may update and change our services from time to time to reflect changes to our products, user needs, and business priorities. We will try to give you reasonable notice of any major changes or may be not.
                        </p>
                        <h4 class="mb-4 animated zoomIn">Governing Law</h4>
                        <p class="pb-0 animated zoomIn">
                            These Terms shall be governed and construed in accordance with the laws of [Your Jurisdiction], without regard to its conflict of law provisions.
                        </p>
                        <h4 class="mb-4 animated zoomIn">Changes to These Terms</h4>
                        <p class="pb-0 animated zoomIn">
                            We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material, we will provide at least 30 days' notice or maybe not prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.
                        </p>
                        <h4 class="mb-4 animated zoomIn">Limitation of Liability</h4>
                        <p class="pb-0 animated zoomIn">
                            To the maximum extent permitted by law, Sinovix shall not be liable for any indirect, incidental, special, consequential, or punitive damages, or any loss of profits or revenues, whether incurred directly or indirectly, or any loss of data, use, goodwill, or other intangible losses, resulting from
                            <ol type="a" class="pb-0 animated zoomIn">
                                <li> Your use or inability to use our services</li>
                                <li> Any unauthorized access to or use of our servers and/or any personal information stored therein</li>
                                <li> Any interruption or cessation of transmission to or from our services</li>
                                <li> Any bugs, viruses, trojan horses, or the like that may be transmitted to or through our services by any third party</li>
                                <li> Any errors or omissions in any content or for any loss or damage incurred as a result of your use of any content posted, emailed, transmitted, or otherwise made available through our services, whether based on warranty, contract, tort (including negligence), or any other legal theory, whether or not we have been informed of the possibility of such damage.</li>
                            </ol>
                        </p>
                        <h4 class="mb-4 animated zoomIn">Privacy Policy</h4>
                        <p class="pb-0 animated zoomIn">
                            Your privacy is important to us. Please review our <a href="privacy-policy.php">Privacy Policy</a>, which also governs your use of our website, to understand our practices.
                        </p>
                        <h4 class="mb-4 animated zoomIn">Cancellation And Termination Of Services</h4>
                        <p class="pb-0 animated zoomIn">
                            You may cancel our services at any time by notifying us that you no longer wish to use our services or website.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            Also we reserve the right to terminate or suspend your access to our website immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms and Conditions.
                        </p>
                        <h4 class="mb-4 animated zoomIn">Payment, Billing & Refund Policy</h4>
                        <p class="pb-0 animated zoomIn">
                            You may check our services at demo time by us and check out all features our ERP Software. You'll see a lot features but these features may dummy of the paid account. 
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Payment Methods : </strong>We accept payments through the methods specified on our website or in the service agreement. These may include credit/debit cards, bank transfers, and other electronic payment methods.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Invoices : </strong>Invoices will be issued according to the terms agreed upon in the service agreement. Payment is due upon receipt unless otherwise specified.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Valid Payment : </strong>Payment is valid only if made directly to the company's official account. We do not take responsibility for any payments made to third parties or unauthorized accounts.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Billing : </strong>Our billing service is annual based. And if you buy any other service like SMS and DLT we will give you billing service at the time of service.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Notification : </strong>If you believe there is an error in your billing, you must contact us in writing within 2 days of the invoice date. Failure to notify us within this period will constitute your acceptance of the charges.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Resolution : </strong>We will investigate all billing disputes and make a determination within 3 working days of receiving your notice. If the dispute is resolved in your favor, we will credit your account for the disputed amount.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Service Charges : </strong>We reserve the right to change the fees for our services at any time. We will provide you with at least 2 days’ notice of any changes to the fees or maybe not.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Refund Policy : </strong>All fees are non-refundable unless explicitly stated otherwise in the service agreement. Please review our <a href="refund-policy.php">Refund Policy</a>, which also governs your use of our website, to understand our practices.
                        </p>
                        <h4 class="mb-4 animated zoomIn">Web Development Services</h4>
                        <p class="pb-0 animated zoomIn">
                            <strong>Project Scope : </strong>We provide custom web development, e-commerce solutions, CMS development, and mobile app development. Each project will have a defined scope agreed upon in the service agreement.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Delivery Timeline : </strong>Project timelines will be outlined in the service agreement. We will make every effort to meet these timelines but are not liable for delays caused by unforeseen circumstances.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Client Responsibilities : </strong>Clients are expected to provide necessary content, feedback, and approvals in a timely manner to facilitate project completion
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Design Ownership : </strong>Upon full payment, the client will own the rights to the final design. We reserve the right to showcase the design in our portfolio unless explicitly requested otherwise by the client.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Acceptance of Work : </strong>The client must review and accept the final design. Any further changes after acceptance may be subject to additional fees.
                        </p>
                        <p class="pb-0 animated zoomIn">
                            <strong>Revisions : </strong>The number of revisions included in the service will be specified in the service agreement. Additional revisions may incur extra charges.
                        </p>
                        <h4 class="mb-4 animated zoomIn">Contact Us</h4>
                        <p class="pb-0 animated zoomIn">
                            If you have any questions or concerns about this Terms and Conditions, please contact us at:
                        </p>
                        <ul class="pb-0 animated zoomIn">
                            <li>Email: info@sinovix.com</li>
                            <li>Phone: +91-7651849593</li>
                            <li>Address: Ground Floor Ramvilas Guest House Jasmai, Bypass Rd, Farrukhabad, Uttar Pradesh - 209625</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Terms End -->
        

        <!-- Footer Start -->
        <?php
            include_once('footer.php');
        ?>
        <!-- Footer End -->