            <!-- Header Start -->
            <?php
                include_once('header.php');
            ?>

            <div class="container-xxl bg-gradient-1 page-header">
                <div class="container text-center">
                    <h1 class="text-white animated zoomIn mb-3">Our Team</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                            <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Our Team</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Navbar & Hero End -->


        <!-- Team Start -->
        <div class="container-xxl py-6">
            <div class="container">
                <div class="mx-auto text-center wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <div class="d-inline-block rounded-pill text-white bg-gradient-1 px-4 mb-3">Our Team</div>
                    <h2 class="mb-5">Meet Our Team Members</h2>
                </div>
                <div class="row g-4">
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="team-item">
                            <h5>Shivin Shrivastav</h5>
                            <p class="mb-4">Founder</p>
                            <img class="img-fluid rounded-circle w-100 mb-4" src="img/team-1.jpg" alt="">
                            <div class="d-flex justify-content-center">
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="team-item">
                            <h5>Ankit Singh Rajput</h5>
                            <p class="mb-4">Director</p>
                            <img class="img-fluid rounded-circle w-100 mb-4" src="img/team-2.jpg" alt="">
                            <div class="d-flex justify-content-center">
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href="https://www.linkedin.com/in/ankitsrajput"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="team-item">
                            <h5>Archit Kumar</h5>
                            <p class="mb-4">PHP Developer</p>
                            <img class="img-fluid rounded-circle w-100 mb-4" src="img/team-3.jpg" alt="">
                            <div class="d-flex justify-content-center">
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href="https://www.linkedin.com/in/archit-kumar-5616ab236"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                        <div class="team-item">
                            <h5>Jatin Gupta</h5>
                            <p class="mb-4">Mern Stack Developer</p>
                            <img class="img-fluid rounded-circle w-100 mb-4" src="img/team-4.jpg" alt="">
                            <div class="d-flex justify-content-center">
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href="https://www.linkedin.com/in/jitin6394"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="team-item">
                            <h5>Full Name</h5>
                            <p class="mb-4">Designation</p>
                            <img class="img-fluid rounded-circle w-100 mb-4" src="img/team-5.jpg" alt="">
                            <div class="d-flex justify-content-center">
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="team-item">
                            <h5>Full Name</h5>
                            <p class="mb-4">Designation</p>
                            <img class="img-fluid rounded-circle w-100 mb-4" src="img/team-5.jpg" alt="">
                            <div class="d-flex justify-content-center">
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="team-item">
                            <h5>Full Name</h5>
                            <p class="mb-4">Designation</p>
                            <img class="img-fluid rounded-circle w-100 mb-4" src="img/team-5.jpg" alt="">
                            <div class="d-flex justify-content-center">
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                        <div class="team-item">
                            <h5>Full Name</h5>
                            <p class="mb-4">Designation</p>
                            <img class="img-fluid rounded-circle w-100 mb-4" src="img/team-5.jpg" alt="">
                            <div class="d-flex justify-content-center">
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Team End -->
        

        <!-- Footer Start -->
        <?php
            include_once('footer.php');
        ?>
        <!-- Footer End -->