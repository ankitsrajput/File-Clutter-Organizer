<?php
    include_once('header.php');
?>

<div class="container-xxl bg-gradient-1 page-header">
                <div class="container text-center">
                    <h1 class="text-white animated zoomIn mb-3">Career</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                            <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Career</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Navbar & Hero End -->

        <!-- Contact Start -->
        <div class="container-xxl py-0">
            <div class="container">
                <div class="mx-auto text-center wow fadeInUp" data-wow-delay="0.1s" style="max-width: 800px;">
                    <h2 class="mb-3">Submit applications for positions that match your interests!</h2>
                    <p class="mb-2">Ensure your resume is updated and tailored for each role. Highlight relevant skills and experiences to increase your chances of success.</p>
                    <p class="mb-4 text-red"><strong>Note : </strong>Please fill in your details carefully to ensure accuracy and avoid any potential issues or delays.</p>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-10 wow fadeInUp" data-wow-delay="0.3s">
                        <form action="sendmail.php" method="Post" enctype="multipart/form-data">
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" name="name" id="name" placeholder="Your Name" required>
                                        <label for="name">Your Full Name *</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-floating">
                                        <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                                        <label for="email">Your Email Address *</label>
                                    </div>
                                </div> 
                                <div class="col-md-4">
                                    <div class="form-floating">
                                        <input type="tel" class="form-control" name="phone" id="mobile" placeholder="phone" pattern="\d{10}" required>
                                        <label for="phone">Contact No. *</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-floating">
                                        <input type="tel" class="form-control" name="altphone" id="mobile" placeholder="phone" pattern="\d{10}" required>
                                        <label for="phone">Alternate Contact No. *</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" name="address" id="address" placeholder="Address" required>
                                        <label for="address">Permanent Address *</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" name="city" id="city" placeholder="City" required>
                                        <label for="city">Your City *</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-floating">
                                        <input type="number" class="form-control" name="pin" id="pin" placeholder="Your Pin" required>
                                        <label for="pin">Pin Code *</label>
                                    </div>
                                </div> 
                                <div class="col-md-4">
                                    <div class="form-floating">
                                        <select name="qualification" class="form-select" id="qualification" required>
                                            <option value="">Select</option>
                                            <option value="10th">10th</option>
                                            <option value="10+2th">10+2th</option>
                                            <option value="B.A">B.A</option>
                                            <option value="B.Sc">B.Sc.</option>
                                            <option value="BCA">BCA</option>
                                            <option value="MCA">MCA</option>
                                            <option value="BBA">BBA</option>
                                            <option value="MBA">MBA</option>
                                            <option value="Computer-Diploma">Computer Diploma</option>
                                            <option value="Other">Other</option>
                                        </select>
                                            <label for="qualification">Highest Qualification *</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-floating">
                                        <select class="form-select" name="position" id="position" required>
                                            <option value="">Select</option>
                                            <option value="Tele-Caller">Tele-Caller</option>
                                            <option value="Sales-Manager">Sales Manager</option>
                                            <option value="Sales-Executive">Sales Executive</option>
                                            <option value="Digital-Marketing">Digital Marketing</option>
                                            <option value="Technical-Supporter">Technical Supporter</option>
                                            <option value="Service-Provider">Service Provider</option>
                                            <option value="Web-Developer">Web Developer</option>
                                            <option value="Other">Other</option>
                                        </select>
                                            <label for="position">Position In Intrested *</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-floating">
                                        <input type="file" accept="application/pdf" class="form-control" name="resume" id="file" placeholder="file" required>
                                        <label for="file">Upload Resume</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-floating">
                                        <textarea class="form-control" placeholder="Leave a message here" name="message" id="message" style="height: 150px"></textarea>
                                        <label for="message">Your Message</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button class="btn btn-primary btn-border bg-gradient-1 w-100 py-3" type="submit" name="send">Send Message</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Contact End -->
<?php
    include_once('footer.php');
?>