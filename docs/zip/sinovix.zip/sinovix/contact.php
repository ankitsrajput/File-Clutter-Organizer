            <?php
                include_once('header.php');
            ?>

            <div class="container-xxl bg-gradient-1 page-header">
                <div class="container text-center">
                    <h1 class="text-white animated zoomIn mb-3">Contact Us</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                            <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Contact</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Navbar & Hero End -->

        <!-- Contact Details Start -->
        <div class="container-xxl py-1">
            <div class="container">
            <div class="mx-auto text-center wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <div class="d-inline-block bg-gradient-1 rounded-pill text-white px-4 mb-3">
                        Contact Us
                    </div>
                    <h2 class="mb-5">If You Have Any Query, Please Feel Free Contact Us</h2>
                    <p class="text-center mb-5">The contact form is currently inactive. Get a functional and working contact form with Ajax & PHP in a few minutes. Just copy and paste the files, add a little code and you're done.</p>
            </div>
                <div class="row g-4">
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                            <div class="d-flex p-4 rounded mb-4 bg-white">
                                <i class="fas fa-map-marker-alt fa-2x text-color-2 me-4"></i>
                                <div>
                                    <h4>Meet to us</h4>
                                    <p class="mb-2">123 Street New York.USA</p>
                                </div>
                            </div>
                    </div>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                            <div class="d-flex p-4 rounded mb-4 bg-white">
                                <i class="fas fa-envelope fa-2x text-color-1 me-4"></i>
                                <div>
                                    <h4>Write to us</h4>
                                    <p class="mb-2">info@sinovix.com</p>
                                </div>
                            </div>
                    </div>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s"> 
                            <div class="d-flex p-4 rounded bg-white">
                                <i class="fa fa-phone-alt fa-2x text-color-2 me-4"></i>
                                <div>
                                    <h4>Reach to us</h4>
                                    <p class="mb-2">+91-7651849593</p>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Contact Details End -->

        <!-- Contact Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="mx-auto text-center wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h2 class="mb-3">We Are Excited To Hear You !</h2>
                    <h4 class="mb-5">Fill The Form</h4>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-8 wow fadeInUp" data-wow-delay="0.3s">
                        <form action="sendmail.php" method="Post">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" name="name" id="name" placeholder="Your Name" required>
                                        <label for="name">Your Name</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                                        <label for="email">Your Email</label>
                                    </div>
                                </div> 
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="tel" class="form-control" name="phone" id="mobile" placeholder="phone" required>
                                        <label for="phone">Phone No.</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <select name="service" class="form-select" id="service" required>
                                            <option value="">Select</option>
                                            <option value="ERP Solution">ERP Solution</option>
                                            <option value="Web Designing">Web Designing</option>
                                            <option value="Other">Other</option>
                                        </select>
                                            <label for="service">Select Service *</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="date" class="form-control" name="date" id="date" placeholder="Meeting Date" required>
                                        <label for="date">Meeting Date</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="time" class="form-control" name="time" id="time" placeholder="time" required >
                                        <label for="time">Meeting Time</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-floating">
                                        <textarea class="form-control" placeholder="Leave a message here" name="message" id="message" style="height: 150px"></textarea>
                                        <label for="message">Message</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button class="btn btn-primary btn-border bg-gradient-1 w-100 py-3" type="submit" name="submit" value="submit">Send Message</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Contact End -->
        <div class="container">
                <div class="mx-auto text-center wow fadeInUp" data-wow-delay="0.1s" style="max-width: 1280px;">
                <iframe src="https://www.google.com/maps/embed?pb=!3m2!1sen!2sin!4v1720898747052!5m2!1sen!2sin!6m8!1m7!1sf0MSmXPMbXKf7xV-pb5qLg!2m2!1d27.38432445118805!2d79.56624032294734!3f46.83230897474222!4f12.209343397890407!5f0.7820865974627469" width="100%" height="350" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
        </div>

        <!-- Footer Start -->
        <?php
            include_once('footer.php');
        ?>
        <!-- Footer End -->