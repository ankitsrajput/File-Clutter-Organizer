        <!-- Navbar & Hero Start -->
            <?php
                include_once('header.php');
            ?>

            <div class="container-xxl bg-gradient-1 page-header">
                <div class="container text-center">
                    <h1 class="text-white animated zoomIn mb-3">About Us</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                            <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">About</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Navbar & Hero End -->


        <!-- About Start -->
        <div class="container-xxl py-6">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6 wow zoomIn" data-wow-delay="0.1s">
                        <img class="img-fluid" src="img/about.png">
                    </div>
                    <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="d-inline-block border rounded-pill text-white bg-gradient-1 px-4 mb-3">About Us</div>
                        <h2 class="mb-4">Leading School ERP Solutions for Optimal Management</h2>
                        <p class="mb-4">Sinovix is a leader in school ERP solutions, dedicated to streamlining educational administration. Our innovative platform enhances efficiency, fosters better communication, and supports academic excellence, ensuring a superior experience for educators and students alike.</p>
                        <div class="row g-3 mb-4">
                            <div class="col-12 d-flex">
                                <div class="flex-shrink-0 btn-lg-square rounded-circle bg-gradient-1">
                                    <i class="fa fa-user-tie text-white"></i>
                                </div>
                                <div class="ms-4">
                                    <h6>Improved Resource Management</h6>
                                    <span>Effectively manage school resources, including staff, finances, and facilities, with ERP solutions, ensuring optimal utilization and cost savings.</span>
                                </div>
                            </div>
                            <div class="col-12 d-flex">
                                <div class="flex-shrink-0 btn-lg-square rounded-circle bg-gradient-1">
                                    <i class="fa fa-chart-line text-white"></i>
                                </div>
                                <div class="ms-4">
                                    <h6>Enhanced Administrative Efficiency</h6>
                                    <span>ERP solutions automate administrative tasks, reducing paperwork and manual errors, thus increasing productivity and efficiency in schools.</span>
                                </div>
                            </div>
                        </div>
                        <!-- <a class="btn btn-primary btn-border bg-gradient-1 rounded-pill py-3 px-5 mt-2" href="about.php">Read More</a> -->
                    </div>
                </div>
            </div>
        </div>
        <!-- About End -->


        <!-- Features Start -->
        <div class="container-xxl py-6">
            <div class="container">
                <div class="row g-5">
                    <div class="col-lg-5 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="d-inline-block rounded-pill text-white px-4 mb-3 bg-gradient-1">Features</div>
                        <h2 class="mb-4">Why Mostly Colleges, Schools, & Institutes Choose Sinovix ?</h2>
                        <p class="p-justify">Colleges, schools, and institutes prefer Sinovix for its comprehensive ERP solutions that streamline administrative tasks, enhance communication, and improve resource management.</p>
                        <p>Our user-friendly platform making it the preferred choice for educational institutions.</p>
                        <a class="btn btn-primary btn-border rounded-pill py-3 px-5 mt-2 bg-gradient-1" href="feature.php">Read More</a>
                    </div>
                    <div class="col-lg-7">
                        <div class="row g-5">
                            <div class="col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="flex-shrink-0 btn-square bg-gradient-1 rounded-circle me-3">
                                        <i class="fa fa-cubes text-white"></i>
                                    </div>
                                    <h6 class="mb-0">Best ERP Solution</h6>
                                </div>
                                <span>Sinovix offers the best ERP solution for schools, colleges, and institutes.</span>
                            </div>
                            <div class="col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="flex-shrink-0 btn-square bg-gradient-1 rounded-circle me-3">
                                        <i class="fa fa-percent text-white"></i>
                                    </div>
                                    <h6 class="mb-0">99.9% Satishfied Clients</h6>
                                </div>
                                <span>We are boasts a 99.9% client satisfaction rate.</span>
                            </div>
                            <div class="col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="flex-shrink-0 btn-square bg-gradient-1 rounded-circle me-3">
                                        <i class="fa fa-file-word text-white"></i>
                                    </div>
                                    <h6 class="mb-0">Fully Customized Reporting</h6>
                                </div>
                                <span>Generate fully customized reports tailored to your school's needs.</span>
                            </div>
                            <div class="col-sm-6 wow fadeInUp" data-wow-delay="0.7s">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="flex-shrink-0 btn-square bg-gradient-1 rounded-circle me-3">
                                        <i class="fa fa-smile-beam text-white"></i>
                                    </div>
                                    <h6 class="mb-0">100% Safe & Secure</h6>
                                </div>
                                <span>Ensure your data is 100% safe & secure with Sinovix, offering robust encryption.</span>
                            </div>
                            <div class="col-sm-6 wow fadeInUp" data-wow-delay="0.9s">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="flex-shrink-0 btn-square bg-gradient-1 rounded-circle me-3">
                                        <i class="fa fa-user-tie text-white"></i>
                                    </div>
                                    <h6 class="mb-0">Multi User Login</h6>
                                </div>
                                <span>Facilitate collaboration and efficient management with multiuser login capabilities.</span>
                            </div>
                            <div class="col-sm-6 wow fadeInUp" data-wow-delay="1s">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="flex-shrink-0 btn-square bg-gradient-1 rounded-circle me-3">
                                        <i class="fa fa-headset text-white"></i>
                                    </div>
                                    <h6 class="mb-0">24/7 Customer Support</h6>
                                </div>
                                <span>Receive round-the-clock assistance with our 24x7 customer support.</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Features End -->


        <!-- Team Start -->
        <div class="container-xxl py-6">
            <div class="container">
                <div class="mx-auto text-center wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <div class="d-inline-block bg-gradient-1 rounded-pill text-white px-4 mb-3">Our Team</div>
                    <h2 class="mb-5">Meet Our Team Members</h2>
                </div>
                <div class="row g-4">
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="team-item">
                            <h5>Shivin Shrivastav</h5>
                            <p class="mb-4">Founder</p>
                            <img class="img-fluid rounded-circle w-100 mb-4" src="img/team-1.jpg" alt="">
                            <div class="d-flex justify-content-center">
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="team-item">
                            <h5>Ankit Singh Rajput</h5>
                            <p class="mb-4">Director</p>
                            <img class="img-fluid rounded-circle w-100 mb-4" src="img/team-2.jpg" alt="">
                            <div class="d-flex justify-content-center">
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href="https://www.linkedin.com/in/ankitsrajput"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="team-item">
                            <h5>Archit Kumar</h5>
                            <p class="mb-4">PHP Developer</p>
                            <img class="img-fluid rounded-circle w-100 mb-4" src="img/team-3.jpg" alt="">
                            <div class="d-flex justify-content-center">
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href="https://www.linkedin.com/in/archit-kumar-5616ab236"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                        <div class="team-item">
                            <h5>Jatin Gupta</h5>
                            <p class="mb-4">Mern Stack</p>
                            <img class="img-fluid rounded-circle w-100 mb-4" src="img/team-4.jpg" alt="">
                            <div class="d-flex justify-content-center">
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square text-color-2 bg-white m-1" href="https://www.linkedin.com/in/jitin6394"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Team End -->
        <!-- Footer Start -->
        <?php
            include_once('footer.php');
        ?>
        <!-- Footer End -->
