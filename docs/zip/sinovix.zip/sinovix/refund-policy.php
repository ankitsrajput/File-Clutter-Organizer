<?php
    include_once('header.php');
?>
<div class="container-xxl bg-gradient-1 page-header">
                <div class="container text-center">
                    <h1 class="text-white animated zoomIn mb-3">Refund Policy</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                            <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Refund Policy</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Navbar & Hero End -->
        <!-- Privacy Policy Start -->
<div class="container-xxl py-0">
            <div class="container">
                <div class="mx-auto text-center wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <div class="d-inline-block rounded-pill text-white bg-gradient-1 px-4 mb-3">How we refund</div>
                    <!-- <h2 class="mb-5">Your Role and Duties</h2> -->
                </div>
                <div class="row g-5 align-items-center">
                    <div class="col-lg-12 text-center text-lg-start">
                        <p class="pb-3 animated zoomIn">
                            We are committed to delivering high-quality services like ERP Solution & website development services. However, we understand that circumstances may arise where a refund is necessary. Please review our refund policy below:
                        </p>
                        <h4 class="mb-4 animated zoomIn">Eligibility for Refunds</h4>
                        <ul class="pb-0 animated zoomIn">
                            <li>Refunds are only available for services specified in your service agreement.</li>
                            <li>If there are substantial delays from our end beyond the agreed-upon timeline.</li>
                            <li>If the client is dissatisfied with the initial service & design concepts and revisions fail to meet expectations.</li>
                            <li>Refund requests must be made within 14 working days of the payment date.</li>
                        </ul>
                        <h4 class="mb-4 animated zoomIn">Non-Refundable Items</h4>
                        <ul class="pb-0 animated zoomIn">
                            <li>Fees for one-time services, such as custom development or design projects, are non-refundable.</li>
                            <li>Any third-party expenses incurred during the project (e.g., domain registration, hosting fees, stock images) are non-refundable.</li>
                            <li>Services rendered up to the point of the refund request, including consultation and design work, are non-refundable</li>
                            <li>Payments for completed project milestones or phases are non-refundable.</li>
                        </ul>
                        <h4 class="mb-4 animated zoomIn">Process for Refunds</h4>
                        <ul class="pb-0 animated zoomIn">
                            <li>To request a refund, contact our support team at <strong>info@sinovix.com</strong> with your service details and reason for the request.</li>
                            <li>Refund requests are reviewed within 3-5 business days.</li>
                            <li>If deemed eligible, refunds will be processed within 5 working days to the original payment method.</li>
                            <li>We will not be liable if you do not request a refund in time.</li>
                        </ul>
                        <h4 class="mb-4 animated zoomIn">Refund Exceptions</h4>
                        <ul class="pb-0 animated zoomIn">
                            <li>No refunds will be issued if you violate our Terms and Conditions.</li>
                            <li>No refunds for disruptions due to events beyond our control, such as natural disasters or technical failures.</li>
                        </ul>
                        <h4 class="mb-4 animated zoomIn">Contact Us</h4>
                        <p class="pb-0 animated zoomIn">
                            If you have any questions or concerns about this Refund Policy, please contact us at:
                        </p>
                        <ul class="pb-0 animated zoomIn">
                            <li>Email: info@sinovix.com</li>
                            <li>Phone: +91-7651849593</li>
                            <li>Address: Ground Floor Ramvilas Guest House Jasmai, Bypass Rd, Farrukhabad, Uttar Pradesh - 209625</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    <!-- Privacy Policy End -->

    <!-- Footer Start -->
    <?php
        include_once('footer.php');
    ?>
    <!-- Footer End -->