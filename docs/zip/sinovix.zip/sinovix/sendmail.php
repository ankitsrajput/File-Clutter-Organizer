<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

include("header.php");
require_once 'mailer/vendor/autoload.php';

$mail = new PHPMailer(true);
// $msg = 'The User has registered as: ' . $_POST['name'] . '<br />Email ID: ' . $_POST['email'] .'<br/>Subject '. $_POST['subject'].'<br/>Message:  ' . $_POST['message'];
if (isset($_POST['submit']))
    {
        try {
                //Server settings
                // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
                $mail->isSMTP();                                            //Send using SMTP
                $mail->Host       = 'webmail.sinovix.com';                     //Set the SMTP server to send through
                $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                $mail->Username   = 'query@sinovix.com';                     //SMTP username
                $mail->Password   = 'Query@#123';                               //SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
                $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

                $services = $_POST['service'];
                if($services === 'ERP Solution')
                {
                    $recipientEmail = 'sinovixmail@gmail.com';
                    $subject = 'Enquiry For A New Software';
                }
                elseif($services === 'Web Designing')
                {
                    $recipientEmail = 'ankitsrajputmail@gmail.com';
                    $subject = 'Enquiry For Web Designing';
                }
                elseif($services === 'Other')
                {
                    $recipientEmail = 'sinovixmail@gmail.com';
                    $mail->addAddress('ankitsrajputmail@gmail.com', 'Sinovix');
                    $subject = 'General Enquiry';
                }
                //Recipients
                $mail->setFrom('query@sinovix.com', 'Sinovix');
                $mail->addAddress($recipientEmail, 'Sinovix');     //Add a recipient
                $mail->addReplyto($recipientEmail, 'Sinovix');
       
                $mail->isHTML(true);                                  //Set email format to HTML
                $mail->Subject = $subject;
                $phoneno = $_POST['phone'];
                // time formatting
                $input_time = $_POST['time'];
                $send_time = date('g:i A', strtotime($input_time));
                // date formatting
                $input_date = $_POST['date'];
                $send_date = date('d-F-Y', strtotime($input_date));
                
                // $mail->Body    = 'Customer Name: ' . $_POST['name'].'<br/>Email : '. $_POST['email']. '<br />Phone: ' . $_POST['phone']. '<br />Subject: ' . $_POST['subject']. '<br />Meeting Date: ' . $send_date.'<br />Meeting Time: ' . $send_time.'<br />Message: ' . $_POST['message'] ;
                $mail->Body = 'Dear Sir/Mam <br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; It is stated that i am ' . $_POST['name']. ' and I am interesting in your ' . $services . ' Service. 
                Please share me all details on my email ' . $_POST['email'] . ' customization, pricing, and security. and Please arrange a meeting 
                on ' . $send_date . ' at ' . $send_time . '.' . ' Whenever you are ready to show me the demo please let me know via call or WhatsApp on the given
                number +91-' . '<a href="tel:' . $phoneno . '">' . $_POST['phone'] .'</a>.' . '<br/><br/>' . '<strong>Additional 
                Message : </strong>' . $_POST['message'] . '<br/><br/><strong>Thank You</strong><br/>' . $_POST['name'];
                $mail->AltBody = '#';

                $mail->send();
                // echo '<script>window.location.href = "../thank-you.php";</script>';
        
                echo '<script>
                     alert("Thank You For Contacting us! We Will Get Back To You Soon.");
                     window.location.href = "../index.php";
                     </script>';
            } 
            catch (Exception $e)
            {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
    }
    // Contact forms code end...
    
    // Now This code starts for careers form...
 if (isset($_POST['send']))
    {
        try {
                //Server settings
                // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
                $mail->isSMTP();                                            //Send using SMTP
                $mail->Host       = 'webmail.sinovix.com';                     //Set the SMTP server to send through
                $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                $mail->Username   = 'query@sinovix.com';                     //SMTP username
                $mail->Password   = 'Query@#123';                               //SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
                $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

                //Recipients
                $mail->setFrom('query@sinovix.com', 'Sinovix');
                $mail->addAddress('sinovixmail@gmail.com', 'Sinovix');     //Add a recipient
                $mail->addAddress('ankitsrajputmail@gmail.com', 'Sinovix');
                $mail->addReplyto('sinovixmail@gmail.com', 'Sinovix');
       
                $mail->isHTML(true);                                  //Set email format to HTML
                $mail->Subject = 'Application For Job Purpose';
                $phoneno = $_POST['phone'];
                $pdf = $_FILES['resume'];
                $pdf_size = 2 * 1024 * 1024; 
                // pdf size validation
                if($pdf['size']>$pdf_size)
                {
                    die('<script> alert("Pdf file size is to large, Maximum file upload size is 2MB.");
                    window.location.href = "../career.php";
                    </script>');
                }
                // pdf size validation end
                
                // pdf file extention validation
                $finfo = new finfo(FILEINFO_MIME_TYPE);
                $fileType = $finfo->file($pdf['tmp_name']);
                if ($fileType !== 'application/pdf')
                {
                    die('<script>alert("Uploaded file is not a valid PDF. Please Upload Valid PDF File");
                    window.location.href="../career.php";</script>');
                }
                // pdf file extention validation end
                
                $mail->Body = 'Dear Respected Sir/Mam,<br/> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This side ' . $_POST['name'] . ' And i am writing to express my interest in 
                the '. $_POST['position'] . ' at your company Sinovix. With a valuable Certificate/Degree/Diploma in ' . $_POST['qualification'] . ' and a strong 
                background in ' . $_POST['position'] . ' And i am confident in my ability to contribute effectively to your team. Please find my detailed resume attached for 
                your consideration.<br/><br/>I am looking forward to the opportunity to discuss how my skills and experiences align with the needs of your organization.
                <br/><br/>Thank you for considering my application.
                <br/><strong>Best regards</strong><br/>'. $_POST['name'] .'<br/>------------------------------<br/>'. '<strong>Full Name : </strong>' . $_POST['name'] . '<br/><strong>E-Mail : </strong>' . $_POST['email'] . '<br/><strong>Phone No. : </strong>' . $_POST['phone'] . '<br/>
                <strong>Alternate Phone No. </strong>: ' . $_POST['altphone'] . '<br/><strong>Permanent Address : </strong>' . $_POST['address'] . '<br/><strong>City : </strong>' . $_POST['city'] . '<br/><strong>Pin : </strong>' . $_POST['pin'] . '
                <br/><strong>Highest Qualification : </strong>' . $_POST['qualification'] . '<br/><strong>Position : </strong>' . $_POST['position'] . '<br/><strong>Message : </strong>' . $_POST['message'] . '<br/><strong>Resume/CV : </strong>' . 'Refer to attachment file.';
                // Pdf File Attachment
                $mail->addAttachment($pdf['tmp_name'], $pdf['name']);
                $mail->AltBody = '#';

                $mail->send();
                // echo '<script>window.location.href = "../thank-you.php";</script>';
        
                echo '<script>
                     alert("Thank You For Contacting us! We Will Get Back To You Soon.");
                     window.location.href = "../index.php";
                     </script>';
            } 
            catch (Exception $e)
            {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
    }
?>